package com.cdut.examplan;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ExamplanApplicationTests {

    @Test
    void contextLoads() {
    }

}
