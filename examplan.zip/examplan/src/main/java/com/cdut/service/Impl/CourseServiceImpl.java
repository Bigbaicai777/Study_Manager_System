package com.cdut.service.Impl;

import com.cdut.entity.Course;
import com.cdut.mapper.ICourseMapper;
import com.cdut.service.ICourseService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CourseServiceImpl implements ICourseService {
    @Autowired
    ICourseMapper courseMapper;

    @Override
    public List<Course> queryAll() {
        return courseMapper.queryAll();
    }

    @Override
    public List<Course> queryCountryCourse() {
        return courseMapper.queryCountryCourse();
    }

    @Override
    public void setCourse(String course_id) {
        courseMapper.setCourse(course_id);
    }


    @Override
    public List<Course> queryNor(String status) {
        return courseMapper.queryNor(status);
    }

    @Override
    public void update(Course course_bas) {
        courseMapper.update(course_bas);
    }

    @Override
    public List<Course> query(String code) {
        return courseMapper.query(code);
    }

    @Override
    public void startByCode(String code) {
        courseMapper.startByCode(code);
    }

    @Override
    public void stopByCode(String code) {
        courseMapper.stopByCode(code);
    }

    @Override
    public void insertCourse(Course course) {
        courseMapper.insertCourse(course);
    }

    @Override
    public List<Course> queryCourseById(String country_course_id) {
        return courseMapper.queryCourseById(country_course_id);
    }

    @Override
    public void deleteById(String country_course_id) {
        courseMapper.deleteById(country_course_id);
    }
}
