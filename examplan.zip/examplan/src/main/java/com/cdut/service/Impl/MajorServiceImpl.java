package com.cdut.service.Impl;

import com.cdut.entity.Major;
import com.cdut.entity.Major_basic;
import com.cdut.entity.Major_school;
import com.cdut.mapper.IMajorMapper;
import com.cdut.service.IMajorService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
@Service
public class MajorServiceImpl implements IMajorService {
    @Autowired
    private IMajorMapper majorMapper;
    @Override
    public List<Major> queryAllCountry_major() {
        return majorMapper.queryAllCountry_major();
    }

    @Override
    public void updateMajor(Major_basic major_basic) {
        majorMapper.updateMajor(major_basic);
    }

    @Override
    public List<Major_basic> findMajorinfoByCode(String code) {
        return majorMapper.findMajorinfoByCode(code);
    }


    @Override
    public void insertMajor(Major_basic major_basic) {
        majorMapper.insertMajor(major_basic);
    }

    @Override
    public List<Major_school> queryAllMajor_school() {
        return majorMapper.queryAllMajor_school();
    }

    @Override
    public List<Major_basic> queryAllMajor() {
        return majorMapper.queryAllMajor();
    }

    @Override
    public List<Major_basic> queryNor(int status) {
        return majorMapper.queryNor(status);
    }

    @Override
    public void deleteMajor(String code) {
        majorMapper.deleteMajor(code);
    }

    @Override
    public void stopByCode(String code) {
        majorMapper.stopByCode(code);
    }

    @Override
    public void startByCode(String code) {
        majorMapper.startByCode(code);
    }

    @Override
    public void updateCountryMajor(Major major) {
        majorMapper.updateCountryMajor(major);
    }

    @Override
    public void deleteCountryMajor(String country_major) {
        majorMapper.deleteCountryMajor(country_major);
    }
}
