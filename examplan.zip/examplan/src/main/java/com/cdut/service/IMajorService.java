package com.cdut.service;

import com.cdut.entity.Major;
import com.cdut.entity.Major_basic;
import com.cdut.entity.Major_school;

import java.util.List;

public interface IMajorService {
    public List<Major> queryAllCountry_major();
    public List<Major_basic> findMajorinfoByCode(String code);
    public void updateMajor(Major_basic major_basic);
    public void insertMajor(Major_basic major_basic);
    public List<Major_school> queryAllMajor_school();
    public List<Major_basic> queryAllMajor();
    public List<Major_basic> queryNor(int status);
    public void deleteMajor(String code);
    public void stopByCode(String code);
    public void startByCode(String code);
    public void updateCountryMajor(Major major);
    public void deleteCountryMajor(String country_major);
}
