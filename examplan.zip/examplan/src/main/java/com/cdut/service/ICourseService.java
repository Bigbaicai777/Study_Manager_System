package com.cdut.service;

import com.cdut.entity.Course;

import java.util.List;

public interface ICourseService {
    public List<Course> queryAll();
    public List<Course> queryCountryCourse();
    public void setCourse(String course_id);
    //public List<Course> showCourse();
    public List<Course> queryNor(String status);
    public void update(Course course_bas);
    public List<Course> query(String code);
    public void startByCode(String code);
    public void stopByCode(String code);
    public void insertCourse(Course course);
    public List<Course> queryCourseById(String country_course_id);
    public void deleteById(String country_course_id);
}
