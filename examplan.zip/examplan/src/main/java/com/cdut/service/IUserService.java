package com.cdut.service;

import com.cdut.entity.User;

public interface IUserService {
    public User getByUsername(String username);
}
