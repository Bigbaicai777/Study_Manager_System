package com.cdut.service.Impl;

import com.cdut.entity.Major_basic;
import com.cdut.entity.ShowMajorCourse;
import com.cdut.mapper.IMajorManagerMapper;
import com.cdut.mapper.IMajorMapper;
import com.cdut.service.IMajorManagerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class MajorManagerServiceImpl implements IMajorManagerService {
    @Autowired
    IMajorManagerMapper majorManagerMapper;
    @Override
    public List<ShowMajorCourse> showMajorCourse() {
        return majorManagerMapper.showMajorCourse();
    }

    @Override
    public List<Major_basic> qureyByCode(String code) {
        return majorManagerMapper.qurreyByCode(code);
    }
}
