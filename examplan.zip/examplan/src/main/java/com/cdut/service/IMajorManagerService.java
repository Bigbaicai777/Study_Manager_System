package com.cdut.service;

import com.cdut.entity.Major_basic;
import com.cdut.entity.ShowMajorCourse;

import java.util.List;

public interface IMajorManagerService {
    public List<ShowMajorCourse> showMajorCourse();
    public List<Major_basic> qureyByCode(String code);
}
