package com.cdut.service.Impl;

import com.cdut.entity.MajorPlan;
import com.cdut.mapper.IMajorPlanMapper;
import com.cdut.service.IMajorPlanService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
@Service
public class MajorPlanServiceImpl implements IMajorPlanService {


    @Autowired
    private IMajorPlanMapper majorPlanMapper;

    @Override
    public void insert(MajorPlan majorPlan) {
        majorPlanMapper.insert(majorPlan);
    }

    @Override
    public List<MajorPlan> queryAll() {
        return majorPlanMapper.queryAll();
    }

    @Override
    public List<MajorPlan> queryMajorCourse(String Major_code) {
        return majorPlanMapper.queryMajorCourse(Major_code);
    }

    @Override
    public List<MajorPlan> queryPlanTable() {
        return majorPlanMapper.queryPlanTable();
    }

    @Override
    public List<MajorPlan> queryCanPublish() {
        return majorPlanMapper.queryCanPublish();
    }

    @Override
    public void update(MajorPlan majorPlan) {
        majorPlanMapper.update(majorPlan);
    }

    @Override
    public void publish(int id) {
        majorPlanMapper.publish(id);
    }

    @Override
    public void pass(int id) {
        majorPlanMapper.pass(id);
    }

    @Override
    public void refuse(int id) {
        majorPlanMapper.refuse(id);
    }

    @Override
    public List<MajorPlan> findById(int id) {
        return majorPlanMapper.findById(id);
    }
}
