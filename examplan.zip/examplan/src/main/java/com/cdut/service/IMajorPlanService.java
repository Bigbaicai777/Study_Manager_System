package com.cdut.service;

import com.cdut.entity.MajorPlan;

import java.util.List;

public interface IMajorPlanService {
    public void insert(MajorPlan majorPlan);
    public List<MajorPlan> queryAll();
    public List<MajorPlan> queryMajorCourse(String Major_code);
    public List<MajorPlan> queryPlanTable();
    public List<MajorPlan> queryCanPublish();
    public void update(MajorPlan majorPlan);
    public void publish(int id);
    public void pass(int id);
    public void refuse(int id);
    public  List<MajorPlan> findById(int id);
}
