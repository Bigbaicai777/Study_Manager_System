package com.cdut.mapper;

import com.cdut.entity.MajorPlan;
import com.cdut.entity.Major_basic;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;
@Mapper
public interface IMajorPlanMapper {
    public void insert(MajorPlan majorPlan);
    public List<MajorPlan> queryAll();
    public List<MajorPlan> queryMajorCourse(String Major_code);
    public List<MajorPlan> queryPlanTable();
    public List<MajorPlan> queryCanPublish();
    public void update(MajorPlan majorPlan);
    public void publish(int id);
    public void pass(int id);
    public void refuse(int id);
    public  List<MajorPlan> findById(int id);
}
