package com.cdut.mapper;

import com.cdut.entity.Major_basic;
import com.cdut.entity.ShowMajorCourse;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

@Mapper
public interface IMajorManagerMapper {
    public List<ShowMajorCourse> showMajorCourse();
    public List<Major_basic> qurreyByCode(String code);
}
