package com.cdut.Dao;

import java.util.List;

import com.cdut.entity.Major_basic;
import org.springframework.stereotype.Repository;


/**
 *  Created By Ayu
 *  2020-01-03
 *  **/

@Repository
public interface Major_basicDao {
	public List<Major_basic> queryAll();
	public void delete(String code);
	public void insert(Major_basic major_bas);
	public void update(Major_basic major_bas);
	public List<Major_basic> query(String code);
	public List<Major_basic> queryNor(int status);
}
