package com.cdut.Dao;

import com.cdut.entity.User;
import org.springframework.stereotype.Repository;



/**
 *  Created By GoghV
 *  2019-12-31
 *  **/
@Repository
public interface UserDao {
	public int insert(User user);
	public int deleteByUsername(String uername);
	public int update(User user);
	public User getByUsername(String username);
}
