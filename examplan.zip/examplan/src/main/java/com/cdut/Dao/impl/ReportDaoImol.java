package com.cdut.Dao.impl;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import com.cdut.Dao.ReportDao;
import com.cdut.entity.CountryCourse;
import com.cdut.entity.MajorSchool;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Service;



@Service
public class ReportDaoImol implements ReportDao {

	@Autowired
	JdbcTemplate jdbcTemplate;
	
	public List<CountryCourse> queryAllCourse() {
		String sql = "select * from course";
	    return this.jdbcTemplate.query(sql, new RowMapper<CountryCourse>() {
	    	 public CountryCourse mapRow(ResultSet resultSet, int i) throws SQLException {
	    		 	CountryCourse countryCourse = new CountryCourse();
	    		 	countryCourse.setCourse_id(resultSet.getString("course_id"));
	    		 	countryCourse.setCountry_course_id(resultSet.getString("country_course_id"));
	    		 	countryCourse.setCourse_name(resultSet.getString("course_name"));
	    		 	countryCourse.setCourse_explain(resultSet.getString("course_explain"));
	    		 	countryCourse.setQuestion_from(resultSet.getString("question_from"));
	    		 	countryCourse.setCourse_status(resultSet.getString("course_status"));
	    		 	countryCourse.setCourse_credit(resultSet.getInt("course_credit"));
	    		 	countryCourse.setQualify_grade(resultSet.getInt("qualify_grade"));
	    		 	countryCourse.setJifen(resultSet.getString("jifen"));
	    		 	countryCourse.setSubject_grade(resultSet.getString("subject_grade"));
	    		 	countryCourse.setObject_grade(resultSet.getString("object_grade"));
	    		 	countryCourse.setTotal_grade(resultSet.getInt("total_grade"));
	    		 	countryCourse.setExam_time(resultSet.getInt("exam_time"));
	    		 	countryCourse.setCourse_type(resultSet.getString("course_type"));
	    		 	return countryCourse;
		        }
	    });
	}

	public List<MajorSchool> queryAllScholl() {
		String sql = "select * from major_school";
	    return this.jdbcTemplate.query(sql, new RowMapper<MajorSchool>() {
	    	 public MajorSchool mapRow(ResultSet resultSet, int i) throws SQLException {
	    		 	MajorSchool majorSchool = new MajorSchool();
	    		 	majorSchool.setMain_school(resultSet.getString("main_school"));
	    		 	majorSchool.setMain_shool_id(resultSet.getInt("main_school_id"));
	    		 	majorSchool.setMajor_code(resultSet.getString("major_code"));	
	    		 	return majorSchool;
		        }
	    });
	}
}
