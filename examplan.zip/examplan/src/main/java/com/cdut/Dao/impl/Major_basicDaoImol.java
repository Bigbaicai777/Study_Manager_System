package com.cdut.Dao.impl;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.cdut.Dao.Major_basicDao;
import com.cdut.entity.Major_basic;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Service;


/**
 *  Created By Ayu
 *  2020-01-03
 *  **/
@Service
public class Major_basicDaoImol implements Major_basicDao {

	@Autowired
	JdbcTemplate jdbcTemplate;
	public List<Major_basic> queryAll() {
		String sql = "select * from major";
	    return this.jdbcTemplate.query(sql, new RowMapper<Major_basic>(){
	        public Major_basic mapRow(ResultSet resultSet, int i) throws SQLException {
	            Major_basic major_bas = new Major_basic();
	            major_bas.setCountry_major_code(resultSet.getString("country_major_code"));
	            major_bas.setMajor_name(resultSet.getString("major_name"));
	            major_bas.setLevel(resultSet.getString("level"));
	            major_bas.setTotal_credit(resultSet.getInt("total_credit"));  
	            major_bas.setExam_explain(resultSet.getString("exam_explain"));
	            major_bas.setGraduate_credit(resultSet.getInt("graduate_credit"));
	            major_bas.setGraduate_explain(resultSet.getString("graduate_explain"));
	            major_bas.setMajor_status(resultSet.getInt("major_status"));
	            major_bas.setMain_school(resultSet.getString("main_school"));
	            major_bas.setMajor_code(resultSet.getString("major_code"));
	            return major_bas;
	        }
	    });
	}

	
	public List<Major_basic> query(String code) {
		// TODO Auto-generated method stub
		String sql = "select * from major where country_major_code = '"+code+"'";
		System.out.println("CODE = "+code);
	    return this.jdbcTemplate.query(sql, new RowMapper<Major_basic>(){
	        public Major_basic mapRow(ResultSet resultSet, int i) throws SQLException {
	            Major_basic major_bas = new Major_basic();
	            major_bas.setCountry_major_code(resultSet.getString("country_major_code"));
	            major_bas.setMajor_name(resultSet.getString("major_name"));
	            major_bas.setLevel(resultSet.getString("level"));
	            major_bas.setTotal_credit(resultSet.getInt("total_credit"));  
	            major_bas.setExam_explain(resultSet.getString("exam_explain"));
	            major_bas.setGraduate_credit(resultSet.getInt("graduate_credit"));
	            major_bas.setGraduate_explain(resultSet.getString("graduate_explain"));
	            major_bas.setMajor_status(resultSet.getInt("major_status"));
	            major_bas.setMain_school(resultSet.getString("main_school"));
	            major_bas.setMajor_code(resultSet.getString("major_code"));
	            return major_bas;
	        }
	    });
		
	}
	
	public void update(Major_basic major_bas) {
		// TODO Auto-generated method stub
		System.out.println("DAO: "+major_bas.toString());
		String sql="update major set country_major_code = ?,major_name = ?,level=?,total_credit=?,exam_explain=?,graduate_credit=?,graduate_explain=?,major_status=?,main_school=?,major_code=? where country_major_code = ?";				 
		jdbcTemplate.update(sql,
				major_bas.getCountry_major_code(),
				major_bas.getMajor_name(),
				major_bas.getLevel(),
				major_bas.getTotal_credit(),
				major_bas.getExam_explain(),
				major_bas.getGraduate_credit(),
				major_bas.getGraduate_explain(),
				major_bas.getMajor_status(),
				major_bas.getMain_school(),
				major_bas.getMajor_code(),
				major_bas.getCountry_major_code()
				);
	}
	
	public void delete(String code) {
		// TODO Auto-generated method stub
		String sql="delete from major where country_major_code = ?";				 
		jdbcTemplate.update(sql,
				code	
				);
}

	public void insert(Major_basic major_bas) {
		// TODO Auto-generated method stub
		String sql="insert into major values(?,?,?,?,?,?,?,?,?,?)";
		jdbcTemplate.update(sql,
				major_bas.getMajor_code(),
				major_bas.getCountry_major_code(),
				major_bas.getMajor_name(),
				major_bas.getLevel(),
				major_bas.getMain_school(),
				major_bas.getMajor_status(),
				major_bas.getTotal_credit(),
				major_bas.getGraduate_credit(),
				major_bas.getExam_explain(),				
				major_bas.getGraduate_explain()						
				);
		
	}


	public List<Major_basic> queryNor(int status) {
		// TODO Auto-generated method stub
		String sql = "select * from major where major_status='"+status+"'";
	    return this.jdbcTemplate.query(sql, new RowMapper<Major_basic>(){
	        public Major_basic mapRow(ResultSet resultSet, int i) throws SQLException {
	            Major_basic major_bas = new Major_basic();
	            major_bas.setCountry_major_code(resultSet.getString("country_major_code"));
	            major_bas.setMajor_name(resultSet.getString("major_name"));
	            major_bas.setLevel(resultSet.getString("level"));
	            major_bas.setTotal_credit(resultSet.getInt("total_credit"));  
	            major_bas.setExam_explain(resultSet.getString("exam_explain"));
	            major_bas.setGraduate_credit(resultSet.getInt("graduate_credit"));
	            major_bas.setGraduate_explain(resultSet.getString("graduate_explain"));
	            major_bas.setMajor_status(resultSet.getInt("major_status"));
	            major_bas.setMain_school(resultSet.getString("main_school"));
	            major_bas.setMajor_code(resultSet.getString("major_code"));
	            return major_bas;
	        }
	    });
	}


	

	

}
