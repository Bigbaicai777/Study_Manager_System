package com.cdut.Dao;

import java.util.List;

import com.cdut.entity.MajorPlan;
import org.springframework.stereotype.Repository;





/**
 * @author GoghV
 * 2020-1-2
 */
@Repository
public interface MajorPlanDao {
	public void insert(MajorPlan majorPlan);
	public List<MajorPlan> queryAll();
	public List<MajorPlan> queryMajorCourse(String Major_code);
	public List<MajorPlan> queryPlanTable();
	public List<MajorPlan> queryCanPublish();
	public void update(MajorPlan majorPlan);
}
