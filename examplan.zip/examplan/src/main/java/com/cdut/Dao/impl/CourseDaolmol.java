package com.cdut.Dao.impl;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletResponse;

import com.cdut.Dao.CourseDao;
import com.cdut.entity.Course;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Service;


@Service
public class CourseDaolmol implements CourseDao {
    @Autowired
    JdbcTemplate jdbcTemplate;

    public void setCourse(String course_id) {
        String sql = "select * from exam_course";

        List<Map<String, Object>> maps = jdbcTemplate.queryForList(sql);
        for (Map<String, Object> map : maps) {

            System.out.println(map.values());
            System.out.println(map.get("course_id"));

        }

    }

    public List<Course> showCourse() {
        String sql = "select * from course";

        List<Course> list = jdbcTemplate.query(sql, new RowMapper<Course>() {

            public Course mapRow(ResultSet rs, int rowNum) throws SQLException {
                Course course = new Course();
                course.setCourse_id(rs.getString(1));
                course.setCountry_course_id(rs.getString(2));
                course.setCourse_name(rs.getString(3));
                course.setCourse_explain(rs.getString(4));
                course.setQuestion_from(rs.getString(5));
                course.setCourse_status(rs.getString(6));
                course.setCourse_credit(rs.getInt(7));
                course.setCourse_grade(rs.getInt(8));
                course.setJifen(rs.getString(9));
                course.setSubject_grade(rs.getString(10));
                course.setObject_grade(rs.getString(11));
                course.setTotal_grade(rs.getInt(12));
                course.setExam_time(rs.getInt(13));
                course.setCourse_type(rs.getString(14));

                System.out.println(course);
                return course;
            }

        });
        return list;

    }

    public List<Course> queryAll() {
        String sql = "select * from course";
        return this.jdbcTemplate.query(sql, new RowMapper<Course>() {
            public Course mapRow(ResultSet rs, int i) throws SQLException {
                Course course = new Course();
                course.setCourse_id(rs.getString("course_id"));
                course.setCountry_course_id(rs.getString("country_course_id"));
                course.setCourse_name(rs.getString("course_name"));
                course.setCourse_explain(rs.getString("course_explain"));
                course.setQuestion_from(rs.getString("question_from"));
                course.setCourse_status(rs.getString("course_status"));
                course.setCourse_credit(rs.getInt("course_credit"));
                course.setCourse_grade(rs.getInt("qualify_grade"));
                course.setJifen(rs.getString("jifen"));
                course.setSubject_grade(rs.getString("subject_grade"));
                course.setObject_grade(rs.getString("object_grade"));
                course.setTotal_grade(rs.getInt("total_grade"));
                course.setExam_time(rs.getInt("exam_time"));
                course.setCourse_type(rs.getString("course_type"));
                return course;
            }
        });
    }

    public List<Course> queryCountryCourse() {
        String sql = "select country_course_id,course_name,course_credit from country_course";
        return this.jdbcTemplate.query(sql, new RowMapper<Course>() {
            public Course mapRow(ResultSet rs, int i) throws SQLException {
                Course course = new Course();
                course.setCountry_course_id(rs.getString("country_course_id"));
                course.setCourse_name(rs.getString("course_name"));
                course.setCourse_credit(rs.getInt("course_credit"));
                return course;
            }
        });
    }

    public List<Course> queryNor(String status) {
        String sql = "select * from course where course_status='" + status + "'";
        return this.jdbcTemplate.query(sql, new RowMapper<Course>() {
            public Course mapRow(ResultSet resultSet, int i) throws SQLException {
                Course course_bas = new Course();
                course_bas.setCountry_course_id(resultSet.getString("country_course_id"));
                course_bas.setCourse_id(resultSet.getString("course_id"));
                course_bas.setCourse_name(resultSet.getString("course_name"));
                course_bas.setCourse_explain(resultSet.getString("course_explain"));
                course_bas.setQuestion_from(resultSet.getString("question_from"));
                course_bas.setCourse_status(resultSet.getString("course_status"));
                course_bas.setCourse_credit(resultSet.getInt("course_credit"));
                course_bas.setCourse_grade(resultSet.getInt("qualify_grade"));
                course_bas.setJifen(resultSet.getString("jifen"));
                course_bas.setSubject_grade(resultSet.getString("subject_grade"));
                course_bas.setObject_grade(resultSet.getString("object_grade"));
                course_bas.setTotal_grade(resultSet.getInt("total_grade"));
                course_bas.setExam_time(resultSet.getInt("exam_time"));
                course_bas.setCourse_type(resultSet.getString("course_type"));
                return course_bas;

            }
        });
    }

    public void update(Course course_bas) {
        // TODO Auto-generated method stub
        System.out.println("DAO: " + course_bas.toString());
        String sql = "update course set country_course_id = ?,course_credit = ?,course_explain = ?,qualify_grade=?,course_name=?,course_status=?,course_type=?,exam_time=?,jifen=?,object_grade=?,question_from=?,subject_grade=?,total_grade=? where country_course_id = ?";
        jdbcTemplate.update(sql,
                course_bas.getCountry_course_id(),
                course_bas.getCourse_credit(),
                course_bas.getCourse_explain(),
                course_bas.getCourse_grade(),
                course_bas.getCourse_name(),
                course_bas.getCourse_status(),
                course_bas.getCourse_type(),
                course_bas.getExam_time(),
                course_bas.getJifen(),
                course_bas.getObject_grade(),
                course_bas.getQuestion_from(),
                course_bas.getSubject_grade(),
                course_bas.getTotal_grade(),
                course_bas.getCourse_id()
        );
    }

    public List<Course> query(String code) {
        // TODO Auto-generated method stub
        String sql = "select * from course where course_id = '" + code + "'";
        System.out.println("CODE = " + code);
        return this.jdbcTemplate.query(sql, new RowMapper<Course>() {
            public Course mapRow(ResultSet resultSet, int i) throws SQLException {
                Course course_bas = new Course();
                course_bas.setCountry_course_id(resultSet.getString("country_course_id"));
                course_bas.setCourse_id(resultSet.getString("course_id"));
                course_bas.setCourse_name(resultSet.getString("course_name"));
                course_bas.setCourse_explain(resultSet.getString("course_explain"));
                course_bas.setQuestion_from(resultSet.getString("question_from"));
                course_bas.setCourse_status(resultSet.getString("course_status"));
                course_bas.setCourse_credit(resultSet.getInt("course_credit"));
                course_bas.setCourse_grade(resultSet.getInt("qualify_grade"));
                course_bas.setJifen(resultSet.getString("jifen"));
                course_bas.setSubject_grade(resultSet.getString("subject_grade"));
                course_bas.setObject_grade(resultSet.getString("object_grade"));
                course_bas.setTotal_grade(resultSet.getInt("total_grade"));
                course_bas.setExam_time(resultSet.getInt("exam_time"));
                course_bas.setCourse_type(resultSet.getString("course_type"));
                return course_bas;
            }
        });

    }
}
	



