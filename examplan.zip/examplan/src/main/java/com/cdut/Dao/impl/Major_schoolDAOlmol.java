package com.cdut.Dao.impl;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import com.cdut.Dao.Major_schoolDao;
import com.cdut.entity.Major_school;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Service;




/**
 * @author Ayu
 * 2020-01-02
 */
@Service
public class Major_schoolDAOlmol implements Major_schoolDao {
	@Autowired
	JdbcTemplate jdbcTemplate;
	public List<Major_school> queryAll() {
		String sql = "select * from major_school";
	    return this.jdbcTemplate.query(sql, new RowMapper<Major_school>(){
	        public Major_school mapRow(ResultSet resultSet, int i) throws SQLException {
	            Major_school major_school = new Major_school();
	            System.out.println(resultSet.getString("major_code"));
	            System.out.println(resultSet.getString("main_school"));
	            System.out.println(resultSet.getInt("main_school_id"));
	            major_school.setMajor_code(resultSet.getString("major_code"));
	            major_school.setMain_school(resultSet.getString("main_school"));
	            major_school.setMain_school_id(resultSet.getInt("main_school_id"));
	            return major_school;
	        }
	    });
	  }
	    
	
	public void insert(Major_school major_school) {
		// TODO Auto-generated method stub
		
	}
	
}
