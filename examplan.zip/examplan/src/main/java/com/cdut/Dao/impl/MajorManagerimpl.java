package com.cdut.Dao.impl;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletResponse;

import com.cdut.Dao.MajorManagerDao;
import com.cdut.entity.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Service;


@Service
public class MajorManagerimpl implements MajorManagerDao {
	@Autowired
	JdbcTemplate jdbcTemplate;
	public void setMajorCourse(MajorCourse mc) {
		String  major_code=mc.getMajor_code();
		String  course_id=mc.getCourse_id();
		String  course_type=mc.getCourse_type();
		String  course_kind=mc.getCourse_kind();
		String  exam_kind=mc.getExam_kind();
		String  exam_type=mc.getExam_type();
		String belong=mc.getBelong();
	String sql="insert into major_course values('"+major_code+"','"+course_id+"','"+course_type+"','"+course_kind+"','"+exam_kind+"','"+exam_type+"','"+belong+"',default)";
	jdbcTemplate.update(sql);
		  
	}

	//change
	public List<ShowMajorCourse> showMajorCourse(String major_code) {
		String sql="SELECT DISTINCT course.course_id,course.course_name,course.course_type,course.course_credit,course.course_explain,course.question_from FROM course WHERE course.course_id NOT IN (SELECT course_id FROM major_course WHERE major_code='"+major_code+"')";

		List<ShowMajorCourse> list=jdbcTemplate.query(sql,new RowMapper<ShowMajorCourse>() {

			public ShowMajorCourse mapRow(ResultSet rs, int rowNum) throws SQLException {
				ShowMajorCourse majorCourse=new ShowMajorCourse();
				majorCourse.setCourse_id(rs.getString("course_id"));
				majorCourse.setCourse_name(rs.getString("course_name"));
				majorCourse.setCourse_type(rs.getString("course_type"));
				majorCourse.setCourse_credit(rs.getInt("course_credit"));
				majorCourse.setCourse_explain(rs.getString("course_explain"));
				majorCourse.setQuestion_from(rs.getString("question_from"));
				System.out.println(majorCourse);
				return majorCourse;
			}

		});
		return list;
	}
	public List<MajorCorseInfo> QurreyMCInfo(String major_code, String course_id) {
		String sql="SELECT course_name,course_credit,major_course.course_type,course_kind FROM course,major_course WHERE course.course_id=major_course.course_id AND major_course.major_code='"+major_code+"'";
		List<MajorCorseInfo> list=jdbcTemplate.query(sql,new RowMapper<MajorCorseInfo>() {

			public MajorCorseInfo mapRow(ResultSet rs, int rowNum) throws SQLException {
				MajorCorseInfo info=new MajorCorseInfo();
				
				info.setCourse_credit(rs.getInt("course_credit"));
				info.setCourse_name(rs.getString("course_name"));
				info.setCourse_type(rs.getString("course_type"));
				info.setCourse_kind(rs.getString("course_kind"));
				
				System.out.println(info);
				return info;
			}
			
		});
		return list;
	}
	public List<Major_basic> qurreyAllMajor() {
		String sql="select * from major";
		List<Major_basic> list=jdbcTemplate.query(sql,new RowMapper<Major_basic>() {

			public Major_basic mapRow(ResultSet rs, int rowNum) throws SQLException {
				Major_basic bs=new Major_basic();
				bs.setCountry_major_code(rs.getString("country_major_code"));
				bs.setMajor_code(rs.getString("major_code"));
				bs.setMajor_name(rs.getString("major_name"));
				bs.setLevel(rs.getString("level"));
				bs.setMajor_status(rs.getInt("major_status"));
				bs.setTotal_credit(rs.getInt("total_credit"));
				bs.setGraduate_credit(rs.getInt("graduate_credit"));
				bs.setExam_explain(rs.getString("exam_explain"));
				bs.setGraduate_explain(rs.getString("graduate_explain"));
				bs.setMain_school(rs.getString("main_school"));
				
				System.out.println(bs);
				return bs;
			}
			
		});
		return list;
	}
	public List<Direction> ManageDir(String major_code) {
		String sql="select * from major_direction where major_code='"+major_code+"'";
		List<Direction> list=jdbcTemplate.query(sql,new RowMapper<Direction>() {

			public Direction mapRow(ResultSet rs, int rowNum) throws SQLException {
				Direction dr=new Direction();
				dr.setDirection_id(rs.getInt("direction_id"));
				dr.setDirection_name(rs.getString("direction_name"));
				dr.setMajor_code(rs.getString("major_code"));
				dr.setTotal_credit(rs.getInt("total_credit"));
				System.out.println(dr);
				return dr;
			}
			
		});
		return list;
	}

	public void updateGra(String major_code, String graduate_explain) {
		System.out.println(major_code+" "+graduate_explain);
		String sql="update major set graduate_explain='"+graduate_explain+"' where major_code='"+major_code+"'";
		jdbcTemplate.execute(sql);
		
		
	}

		
		
		
	
		 		 
}


