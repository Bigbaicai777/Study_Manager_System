package com.cdut.Dao.impl;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.cdut.Dao.MajorDao;
import com.cdut.entity.Major;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Service;



/**
 *  Created By GoghV
 *  2020-09-13
 *  **/
@Service
public class MajorDaoImol implements MajorDao {

	@Autowired
	JdbcTemplate jdbcTemplate;
	public List<Major> queryAll() {
		String sql = "select * from country_major";
	    return this.jdbcTemplate.query(sql, new RowMapper<Major>(){
	        public Major mapRow(ResultSet resultSet, int i) throws SQLException {
	            Major major = new Major();
	            major.setCountry_major(resultSet.getString("country_major"));
	            major.setMajor_name(resultSet.getString("major_name"));
	            major.setLevel(resultSet.getString("level"));
	            major.setTotal_credit(resultSet.getInt("total_credit"));
	            return major;
	        }
	    });
	}

	public void update(Major major) {
		// TODO Auto-generated method stub
		
	}

	public void insert(Major major) {
		// TODO Auto-generated method stub
		
	}

}
