
package com.cdut.Dao;

import java.util.List;

import com.cdut.entity.Course;
import com.cdut.entity.Exam;
import com.cdut.entity.ExamPlan;
import com.cdut.entity.ExamTime;
import org.springframework.stereotype.Repository;



/**
 * @author 大白菜
 *
 */
@Repository
public interface ExamManagerDao {
	public List<Exam> qurryAllExam();
	public int addExamPlan(String exam_id, String major_code);
	public List<Course> qurrtAllMajor();
	public List<ExamTime> qurrtAllTime();
	public int insertById(String exam_id, String course_id, String time_id);
	public List<ExamPlan> qurrtAllExamPlan();
	
}
