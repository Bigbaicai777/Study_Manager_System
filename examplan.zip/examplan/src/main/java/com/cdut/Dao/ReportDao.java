package com.cdut.Dao;

import java.util.List;

import com.cdut.entity.CountryCourse;
import com.cdut.entity.MajorSchool;
import org.springframework.stereotype.Repository;


@Repository
public interface ReportDao {
	public List<CountryCourse> queryAllCourse();
	public List<MajorSchool> queryAllScholl();
}
