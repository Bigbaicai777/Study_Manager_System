package com.cdut.Dao;

import com.cdut.entity.Time;

import java.util.List;



public interface TimeDao {

	public List<Time> queryAll();
	public List<Time> queryExamCourse();
	public List<Time> showTime();
	public void setExamTime(String exam_id);
	public void setTime(String exam_id);
	public List<Time> showExamTime();
}
