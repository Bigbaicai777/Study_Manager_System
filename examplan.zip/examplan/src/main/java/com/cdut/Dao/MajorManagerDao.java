package com.cdut.Dao;

import java.util.List;

import javax.servlet.http.HttpServletResponse;

import com.cdut.entity.*;
import org.springframework.stereotype.Repository;



@Repository
public interface MajorManagerDao {
	public void setMajorCourse(MajorCourse mc);
	public List<ShowMajorCourse> showMajorCourse(String major_code);
	public List<MajorCorseInfo> QurreyMCInfo(String major_code, String course_id);
	public List<Major_basic> qurreyAllMajor();
	public List<Direction> ManageDir(String major_code);
	public void updateGra(String major_coede, String graduate_explain);
}
