package com.cdut.Dao.impl;

import com.cdut.Dao.UserDao;
import com.cdut.entity.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;


/**
 *  Created By GoghV
 *  2019-12-31
 *  **/

@Service
public class UserDaoImol implements UserDao {
	
	@Autowired
	JdbcTemplate jdbcTemplate;
	
	/*public int insert(User user) {
		// ����User��������û�
		String sql = "insert into Users(username,password,status) values(?,?,?)";
		String username = user.getUsername();
		String password = user.getPassword();
		int status = user.getStatus();
		jdbcTemplate.update(
				sql,
				username,
				password,
				status);
		return 0;
	}*/

	@Override
	public int insert(User user) {
		return 0;
	}

	public int deleteByUsername(String uername) {
		// TODO Auto-generated method stub
		return 0;
	}

	public int update(User user) {
		// TODO Auto-generated method stub
		return 0;
	}

	public User getByUsername(String username) {
		// TODO Auto-generated method stub
		return null;
	}

}
