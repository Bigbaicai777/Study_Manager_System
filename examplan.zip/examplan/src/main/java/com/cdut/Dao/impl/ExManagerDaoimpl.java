
package com.cdut.Dao.impl;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.List;

import com.cdut.Dao.ExamManagerDao;
import com.cdut.entity.Course;
import com.cdut.entity.Exam;
import com.cdut.entity.ExamPlan;
import com.cdut.entity.ExamTime;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Service;



/**
 * @author 大白菜
 *
 */
@Service
public class ExManagerDaoimpl implements ExamManagerDao {

	@Autowired
	JdbcTemplate jdbcTemplate;
	
	public List<Exam> qurryAllExam() {
		String sql="select * from exam where plan_exam_status='未用'";
		List<Exam> list=jdbcTemplate.query(sql,new RowMapper<Exam>() {

			public Exam mapRow(ResultSet rs, int rowNum) throws SQLException {
				Exam exam=new Exam();
				exam.setExam_id(rs.getString("exam_id"));
				exam.setExam_type(rs.getString("exam_type"));
				exam.setPlan_exam_status(rs.getString("plan_exam_status"));
				exam.setStart_date(new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(rs.getTimestamp("start_date")));
				exam.setEnd_date(new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(rs.getTimestamp("end_date")));
				System.out.println(exam);
				return exam;
			}
			
		});
		return list;
		
	}

	public int addExamPlan(String exam_id, String major_code) {
		String sql="insert into exam_major(exam_id,major_code) values('"+exam_id+"','"+major_code+"')";
		System.out.println(sql);
		return jdbcTemplate.update(sql);
		
	}

	public List<Course> qurrtAllMajor() {
			String sql="select * from course where course_status='正常'";
			List<Course> list=jdbcTemplate.query(sql,new RowMapper<Course>() {

				public Course mapRow(ResultSet rs, int rowNum) throws SQLException {
					Course c=new Course();
					c.setCourse_id(rs.getString("course_id"));
					c.setCourse_name(rs.getString("course_name"));
					c.setCourse_credit(rs.getInt("course_credit"));
					c.setExam_time(rs.getInt("exam_time"));
					
					return c;
				}
				
			});
			return list;
			
	}

	public List<ExamTime> qurrtAllTime() {
		
		String sql="select * from exam_course ";
		List<ExamTime> list=jdbcTemplate.query(sql,new RowMapper<ExamTime>() {

			public ExamTime mapRow(ResultSet rs, int rowNum) throws SQLException {
				ExamTime t=new ExamTime();
					t.setExam_id(rs.getString("exam_id"));
					t.setTime_id(rs.getString("time_id"));
					t.setDate(new SimpleDateFormat("yyyy-MM-dd").format(rs.getDate("date")));
					t.setStart_time(new SimpleDateFormat("HH:mm:ss").format(rs.getTime("start_time")));
					t.setEnd_time(new SimpleDateFormat("HH:mm:ss").format(rs.getTime("end_time")));
				return t;
			}
			
		});
		return list;
	}

	public int insertById(String exam_id, String course_id, String time_id) {
		String sql="insert into exam_course_date(exam_id,time_id,course_id) values('"+exam_id+"','"+time_id+"','"+course_id+"')";
		return jdbcTemplate.update(sql);
	}

	public List<ExamPlan> qurrtAllExamPlan() {
		String sql="select * from exam_plan_check ";
		List<ExamPlan> list=jdbcTemplate.query(sql,new RowMapper<ExamPlan>() {

			public ExamPlan mapRow(ResultSet rs, int rowNum) throws SQLException {
				ExamPlan t=new ExamPlan();
					t.setExam_id(rs.getString("exam_id"));
					t.setExam_plan_check_status(rs.getString("exam_plan_check_status"));
					t.setLeader_suggest(rs.getString("leader_suggest"));
					t.setPlan_check_suggest(rs.getString("plan_check_suggest"));
					t.setXuelichu_suggest(rs.getString("xuelichu_suggest"));
				return t;
			}
			
		});
		return list;
	}
	
}
