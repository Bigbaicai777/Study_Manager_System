package com.cdut.Dao.impl;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletResponse;

import com.cdut.Dao.TimeDao;
import com.cdut.entity.Time;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Service;



@Service
public  class TimeDaolmol implements TimeDao {
	@Autowired
	JdbcTemplate jdbcTemplate;
	//����ʱ��
	public void setExamTime(String exam_id) {
		String sql="select *from exam_course";
		
		List<Map<String, Object>> maps=jdbcTemplate.queryForList(sql);
		for (Map<String, Object> map : maps) { 
			
			System.out.println(map.values());
			System.out.println(map.get("exam_id"));
			  
		}
		  
	}
	//����ʱ��
	public void setTime(String exam_id) {
		String sql="select *from exam";
		
		List<Map<String, Object>> maps=jdbcTemplate.queryForList(sql);
		for (Map<String, Object> map : maps) { 
			
			System.out.println(map.values());
			System.out.println(map.get("exam_id"));
			  
		}
		  
	}
    //����
	  public List<Time> showTime() {
		  String sql="select*from exam";
	  
	  List<Time> list=jdbcTemplate.query(sql,new RowMapper<Time>() {
	  
	  public Time mapRow(ResultSet rs, int rowNum) throws SQLException { 
		  Time time = new Time();
		  time.setExam_id(rs.getString("exam_id"));
		  time.setExam_type(rs.getString("exam_type"));
		  time.setPlan_exam_status(rs.getString("plan_exam_status"));
		  time.setStart_date(rs.getString("start_date"));
		  time.setEnd_date(rs.getString("end_date"));
		  time.setExam_free(rs.getInt("exam_free"));
      
	  System.out.println(time); 
	  return time; }
	  
	  }); 
	  return list;
	  }
	  //����ʱ��
	  public List<Time> showExamTime() { 
		  String sql="select*from exam_course";
	  
	  List<Time> list=jdbcTemplate.query(sql,new RowMapper<Time>() {
	  
	  public Time mapRow(ResultSet rs, int rowNum) throws SQLException { 
		  Time time = new Time();
  		  time.setExam_id(rs.getString("exam_id"));
  		  time.setTime_id(rs.getString("time_id"));
  		  time.setDate(rs.getString("date"));
  		  time.setStart_time(rs.getString("start_time"));
  		  time.setEnd_time(rs.getString("end_time"));
      
	  System.out.println(time); 
	  return time; }
	  
	  }); 
	  return list;
	  }
	 
	public List<Time> queryAll() {
		String sql="select * from exam";
	    return this.jdbcTemplate.query(sql, new RowMapper<Time>(){
	        public Time mapRow(ResultSet rs, int i) throws SQLException {
	          Time time = new Time();
	  		  time.setExam_id(rs.getString("exam_id"));
	  		  time.setExam_type(rs.getString("exam_type"));
	  		  time.setPlan_exam_status(rs.getString("plan_exam_status"));
	  		  time.setStart_date(rs.getString("start_date"));
	  		  time.setEnd_date(rs.getString("end_date"));
	  		  time.setExam_free(rs.getInt("exam_free"));
	            return time;
	        }
	    });
	}
	
	public List<Time> queryExamCourse() {
		String sql="select * from exam_course";
	    return this.jdbcTemplate.query(sql, new RowMapper<Time>(){
	        public Time mapRow(ResultSet rs, int i) throws SQLException {
	          Time time = new Time();
	  		  time.setExam_id(rs.getString("exam_id"));
	  		  time.setTime_id(rs.getString("time_id"));
	  		  time.setDate(rs.getString("date"));
	  		  time.setStart_time(rs.getString("start_time"));
	  		  time.setEnd_time(rs.getString("end_time"));
	            return time;
	        }
	    });
	}

}


