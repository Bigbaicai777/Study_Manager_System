package com.cdut.Dao;

import java.util.List;

import com.cdut.entity.Major;
import org.springframework.stereotype.Repository;


/**
 *  Created By GoghV
 *  2020-01-01
 *  **/

@Repository
public interface MajorDao {
	public List<Major> queryAll();
	public void update(Major major);
	public void insert(Major major);
}
