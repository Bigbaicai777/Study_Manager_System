package com.cdut.Dao.impl;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import com.cdut.Dao.MajorPlanDao;
import com.cdut.entity.MajorPlan;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Service;



/**
 * @author GoghV
 * 2020-1-2
 */

@Service
public class MajorPlanDaoImol implements MajorPlanDao {

	@Autowired
	JdbcTemplate jdbcTemplate;
	public void insert(MajorPlan majorPlan) {
		String tempMajorCode = majorPlan.getMajor_code();
		if(tempMajorCode.length()<7)tempMajorCode+=String.valueOf((int)Math.random()*9);
		else tempMajorCode = tempMajorCode.substring(0,tempMajorCode.length()-3)+String.valueOf((int)Math.random()*9);
		majorPlan.setMajor_code(tempMajorCode);
		String sql = "insert into plan_table(plan_version,plan_name,status,"
				+ "create_date,approval_status,xuelichu_suggest,"
				+ "leader_idea,major_code) values(?,?,?,?,?,?,?,?) ";
		jdbcTemplate.update(
				sql,
				majorPlan.getPlan_version(),
				majorPlan.getPlan_name(),
				majorPlan.getStatus(),
				majorPlan.getCreate_date(),
				majorPlan.getApproval_status(),
				majorPlan.getXuelichu_suggest(),
				majorPlan.getLeader_idea(),
				majorPlan.getMajor_code()
				);
		sql = "insert into major_course(major_code,course_id,course_type,course_kind,exam_kind,exam_type,belong)"
				+ "values(?,?,?,?,?,?,?)";
		jdbcTemplate.update(
				sql,
				majorPlan.getMajor_code(),
				majorPlan.getCourse_id(),
				majorPlan.getCourse_type(),
				majorPlan.getCourse_kind(),
				majorPlan.getExam_kind(),
				majorPlan.getExam_type(),
				majorPlan.getBelong()
				);
	}

	public List<MajorPlan> queryAll() {
		String sql = "select * from plan_table";
	    return this.jdbcTemplate.query(sql, new RowMapper<MajorPlan>() {
	    	 public MajorPlan mapRow(ResultSet resultSet, int i) throws SQLException {
		            MajorPlan majorPlan = new MajorPlan();
		            majorPlan.setId(resultSet.getInt("id"));;
		            majorPlan.setPlan_version(resultSet.getString("plan_version"));
		            majorPlan.setPlan_name(resultSet.getString("plan_name"));
		            majorPlan.setStatus(resultSet.getString("status"));
		            majorPlan.setCreate_date(resultSet.getDate("create_date"));
		            majorPlan.setApproval_status(resultSet.getString("approval_status"));
		            majorPlan.setXuelichu_suggest(resultSet.getString("xuelichu_suggest"));
		            majorPlan.setLeader_idea(resultSet.getString("leader_idea"));
		            majorPlan.setMajor_code(resultSet.getString("major_code"));
		            return majorPlan;
		        }
	    });
	}

	public void update(MajorPlan majorPlan) {
		// TODO Auto-generated method stub
		System.out.println(majorPlan.toString());
		String sql = "update plan_table SET plan_version=?,plan_name=?,"
				+ "status=?,create_date=?,approval_status=?,xuelichu_suggest=?,leader_idea=?,major_code=? where id = ?";
		jdbcTemplate.update(
				sql,
				majorPlan.getPlan_version(),
				majorPlan.getPlan_name(),
				majorPlan.getStatus(),
				majorPlan.getCreate_date(),
				majorPlan.getApproval_status(),
				majorPlan.getXuelichu_suggest(),
				majorPlan.getLeader_idea(),
				majorPlan.getMajor_code(),
				majorPlan.getId()
				);
		sql = "update major_course SET course_id=?,course_type=?,course_kind=?,"
				+ "exam_kind=?,exam_type=?,belong=? where major_code = ?";
		jdbcTemplate.update(
				sql,
				majorPlan.getCourse_id(),
				majorPlan.getCourse_type(),
				majorPlan.getCourse_kind(),
				majorPlan.getExam_kind(),
				majorPlan.getExam_type(),
				majorPlan.getBelong(),
				majorPlan.getMajor_code()
				);
	}

	public List<MajorPlan> queryMajorCourse(String major_code) {
		String sql = "select * from plan_table join major_course on plan_table.major_code ='"+major_code+"' "
				+ "and major_course.major_code = '"+major_code+"';";
	    return this.jdbcTemplate.query(sql, new RowMapper<MajorPlan>() {
	    	 public MajorPlan mapRow(ResultSet resultSet, int i) throws SQLException {
		            MajorPlan majorPlan = new MajorPlan();
		            majorPlan.setId(resultSet.getInt("id"));;
		            majorPlan.setPlan_version(resultSet.getString("plan_version"));
		            majorPlan.setPlan_name(resultSet.getString("plan_name"));
		            majorPlan.setStatus(resultSet.getString("status"));
		            majorPlan.setCreate_date(resultSet.getDate("create_date"));
		            majorPlan.setApproval_status(resultSet.getString("approval_status"));
		            majorPlan.setXuelichu_suggest(resultSet.getString("xuelichu_suggest"));
		            majorPlan.setLeader_idea(resultSet.getString("leader_idea"));
		            majorPlan.setMajor_code(resultSet.getString("major_code"));
		            majorPlan.setCourse_type(resultSet.getString("course_type"));
		            majorPlan.setCourse_kind(resultSet.getString("course_kind"));
		            majorPlan.setExam_kind(resultSet.getString("exam_kind"));
		            majorPlan.setExam_type(resultSet.getString("exam_type"));
		            majorPlan.setBelong(resultSet.getString("belong"));
		            majorPlan.setCourse_id(resultSet.getString("course_id"));
		            return majorPlan;
		        }
	    });
	}

	public List<MajorPlan> queryMajorCourse() {
		// TODO Auto-generated method stub
		return null;
	}

	public List<MajorPlan> queryPlanTable() {
		String sql = "select * from plan_table where xuelichu_suggest = '审核中'";
	    return this.jdbcTemplate.query(sql, new RowMapper<MajorPlan>() {
	    	 public MajorPlan mapRow(ResultSet resultSet, int i) throws SQLException {
		            MajorPlan majorPlan = new MajorPlan();
		            majorPlan.setId(resultSet.getInt("id"));;
		            majorPlan.setPlan_version(resultSet.getString("plan_version"));
		            majorPlan.setPlan_name(resultSet.getString("plan_name"));
		            majorPlan.setStatus(resultSet.getString("status"));
		            majorPlan.setCreate_date(resultSet.getDate("create_date"));
		            majorPlan.setApproval_status(resultSet.getString("approval_status"));
		            majorPlan.setXuelichu_suggest(resultSet.getString("xuelichu_suggest"));
		            majorPlan.setLeader_idea(resultSet.getString("leader_idea"));
		            majorPlan.setMajor_code(resultSet.getString("major_code"));
		            return majorPlan;
		        }
	    });
	}

	public List<MajorPlan> queryCanPublish() {
		String sql = "select * from plan_table where xuelichu_suggest = '通过' and leader_idea='通过' ";
	    return this.jdbcTemplate.query(sql, new RowMapper<MajorPlan>() {
	    	 public MajorPlan mapRow(ResultSet resultSet, int i) throws SQLException {
		            MajorPlan majorPlan = new MajorPlan();
		            majorPlan.setId(resultSet.getInt("id"));;
		            majorPlan.setPlan_version(resultSet.getString("plan_version"));
		            majorPlan.setPlan_name(resultSet.getString("plan_name"));
		            majorPlan.setStatus(resultSet.getString("status"));
		            majorPlan.setCreate_date(resultSet.getDate("create_date"));
		            majorPlan.setApproval_status(resultSet.getString("approval_status"));
		            majorPlan.setXuelichu_suggest(resultSet.getString("xuelichu_suggest"));
		            majorPlan.setLeader_idea(resultSet.getString("leader_idea"));
		            majorPlan.setMajor_code(resultSet.getString("major_code"));
		            return majorPlan;
		        }
	    });
	}
	
}
