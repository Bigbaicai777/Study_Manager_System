package com.cdut.Dao;
import java.util.List;

import com.cdut.entity.Major_school;
import org.springframework.stereotype.Repository;



/**
 * @author Ayu
 * 2010-01-02
 */

@Repository
public interface Major_schoolDao {
	public List<Major_school> queryAll();
//	public void update(Major_school major_school);
	public void insert(Major_school major_school);
}
