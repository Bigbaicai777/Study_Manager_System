package com.cdut.entity;

public class CountryCourse {
	String course_id;
	String country_course_id;
	String course_name;
	String course_explain;
	String question_from;
	int course_credit;
	int qualify_grade;
	String course_status;
	String jifen;
	String subject_grade;
	String object_grade;
	int total_grade;
	int exam_time;
	String course_type;
	
	public String getCourse_status() {
		return course_status;
	}
	public void setCourse_status(String course_status) {
		this.course_status = course_status;
	}
	public String getCountry_course_id() {
		return country_course_id;
	}
	public void setCountry_course_id(String country_course_id) {
		this.country_course_id = country_course_id;
	}
	public String getCourse_name() {
		return course_name;
	}
	public void setCourse_name(String course_name) {
		this.course_name = course_name;
	}
	public int getCourse_credit() {
		return course_credit;
	}
	public void setCourse_credit(int course_credit) {
		this.course_credit = course_credit;
	}
	public String getCourse_id() {
		return course_id;
	}
	public void setCourse_id(String course_id) {
		this.course_id = course_id;
	}
	public String getCourse_explain() {
		return course_explain;
	}
	public void setCourse_explain(String course_explain) {
		this.course_explain = course_explain;
	}
	public String getQuestion_from() {
		return question_from;
	}
	public void setQuestion_from(String question_from) {
		this.question_from = question_from;
	}
	public int getQualify_grade() {
		return qualify_grade;
	}
	public void setQualify_grade(int qualify_grade) {
		this.qualify_grade = qualify_grade;
	}
	public String getJifen() {
		return jifen;
	}
	public void setJifen(String jifen) {
		this.jifen = jifen;
	}
	public String getSubject_grade() {
		return subject_grade;
	}
	public void setSubject_grade(String subject_grade) {
		this.subject_grade = subject_grade;
	}
	public String getObject_grade() {
		return object_grade;
	}
	public void setObject_grade(String object_grade) {
		this.object_grade = object_grade;
	}
	public int getTotal_grade() {
		return total_grade;
	}
	public void setTotal_grade(int total_grade) {
		this.total_grade = total_grade;
	}
	public int getExam_time() {
		return exam_time;
	}
	public void setExam_time(int exam_time) {
		this.exam_time = exam_time;
	}
	public String getCourse_type() {
		return course_type;
	}
	public void setCourse_type(String course_type) {
		this.course_type = course_type;
	}
	@Override
	public String toString() {
		return "CountryCourse [course_id=" + course_id + ", country_course_id=" + country_course_id + ", course_name="
				+ course_name + ", course_explain=" + course_explain + ", question_from=" + question_from
				+ ", course_credit=" + course_credit + ", qualify_grade=" + qualify_grade + ", jifen=" + jifen
				+ ", subject_grade=" + subject_grade + ", object_grade=" + object_grade + ", total_grade=" + total_grade
				+ ", exam_time=" + exam_time + ", course_type=" + course_type + "]";
	}
	
	
}
