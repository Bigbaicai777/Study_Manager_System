
package com.cdut.entity;

/**
 * @author 大白菜
 *
 */
public class ExamTime {
	private String exam_id;
	private String time_id;
	private String date;
	private String start_time;
	private String end_time;
	public String getExam_id() {
		return exam_id;
	}
	public void setExam_id(String exam_id) {
		this.exam_id = exam_id;
	}
	public String getTime_id() {
		return time_id;
	}
	public void setTime_id(String time_id) {
		this.time_id = time_id;
	}
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	public String getStart_time() {
		return start_time;
	}
	public void setStart_time(String start_time) {
		this.start_time = start_time;
	}
	public String getEnd_time() {
		return end_time;
	}
	public void setEnd_time(String end_time) {
		this.end_time = end_time;
	}
	@Override
	public String toString() {
		return "ExamTime [exam_id=" + exam_id + ", time_id=" + time_id + ", date=" + date + ", start_time=" + start_time
				+ ", end_time=" + end_time + "]";
	}
	
}
