package com.cdut.entity;

/**
 *  Created By Ayu
 *  2020-01-03
 *  **/

public class Major_basic {
	private String major_code; //רҵ����
	private String country_major_code; //����רҵ����
	private String major_name; //רҵ����
	private String level; //ѧ�����  ���ơ�ר��
	private String main_school;//����ԺУ
	private int major_status;//רҵ״̬   ����/ͣ��
	private int total_credit;//��ѧ��
	private int graduate_credit;//��ҵѧ��
	private String exam_explain;//��������˵��
	private String graduate_explain;//��ҵ����˵��
	
	public String getMajor_code() {
		return major_code;
	}
	public void setMajor_code(String major_code) {
		this.major_code = major_code;
	}
	public String getCountry_major_code() {
		return country_major_code;
	}
	public void setCountry_major_code(String country_major_code) {
		this.country_major_code = country_major_code;
	}
	public String getMajor_name() {
		return major_name;
	}
	public void setMajor_name(String major_name) {
		this.major_name = major_name;
	}
	public String getLevel() {
		return level;
	}
	public void setLevel(String level) {
		this.level = level;
	}
	public String getMain_school() {
		return main_school;
	}
	public void setMain_school(String main_school) {
		this.main_school = main_school;
	}
	public int getMajor_status() {
		return major_status;
	}
	public void setMajor_status(int major_status) {
		this.major_status = major_status;
	}
	public int getTotal_credit() {
		return total_credit;
	}
	public void setTotal_credit(int total_credit) {
		this.total_credit = total_credit;
	}
	public int getGraduate_credit() {
		return graduate_credit;
	}
	public void setGraduate_credit(int graduate_credit) {
		this.graduate_credit = graduate_credit;
	}
	public String getExam_explain() {
		return exam_explain;
	}
	public void setExam_explain(String exam_explain) {
		this.exam_explain = exam_explain;
	}
	public String getGraduate_explain() {
		return graduate_explain;
	}
	public void setGraduate_explain(String graduate_explain) {
		this.graduate_explain = graduate_explain;
	}
	@Override
	public String toString() {
		return "Major_basic [major_code=" + major_code + ", country_major_code=" + country_major_code + ", major_name="
				+ major_name + ", level=" + level + ", main_school=" + main_school + ", major_status=" + major_status
				+ ", total_credit=" + total_credit + ", graduate_credit=" + graduate_credit + ", exam_explain="
				+ exam_explain + ", graduate_explain=" + graduate_explain + "]";
	}
	
	
}
