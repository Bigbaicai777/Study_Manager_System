
package com.cdut.entity;

/**
 * @author ��ײ�
 *
 */
public class ShowMajorCourse {
	private String course_id;
	private String course_name;
	private int course_credit;
	private String course_type;
	private String question_from;
	private String course_explain;
	
	public String getQuestion_from() {
		return question_from;
	}
	public void setQuestion_from(String question_from) {
		this.question_from = question_from;
	}
	public String getCourse_explain() {
		return course_explain;
	}
	public void setCourse_explain(String course_explain) {
		this.course_explain = course_explain;
	}

	@Override
	public String toString() {
		return "ShowMajorCourse [course_id=" + course_id + ", course_name=" + course_name + ", course_credit="
				+ course_credit + ", course_type=" + course_type + ", question_from=" + question_from
				+ ", course_explain=" + course_explain + "]";
	}
	public String getCourse_id() {
		return course_id;
	}
	public void setCourse_id(String course_id) {
		this.course_id = course_id;
	}
	public String getCourse_name() {
		return course_name;
	}
	public void setCourse_name(String course_name) {
		this.course_name = course_name;
	}
	public int getCourse_credit() {
		return course_credit;
	}
	public void setCourse_credit(int course_credit) {
		this.course_credit = course_credit;
	}
	public String getCourse_type() {
		return course_type;
	}
	public void setCourse_type(String course_type) {
		this.course_type = course_type;
	}


	

}
