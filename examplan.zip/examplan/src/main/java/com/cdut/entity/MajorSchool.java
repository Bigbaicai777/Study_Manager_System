package com.cdut.entity;

public class MajorSchool {
	String major_code;
	String main_school;
	int main_shool_id;
	public String getMajor_code() {
		return major_code;
	}
	public void setMajor_code(String major_code) {
		this.major_code = major_code;
	}
	public String getMain_school() {
		return main_school;
	}
	public void setMain_school(String main_school) {
		this.main_school = main_school;
	}
	public int getMain_shool_id() {
		return main_shool_id;
	}
	public void setMain_shool_id(int main_shool_id) {
		this.main_shool_id = main_shool_id;
	}
	@Override
	public String toString() {
		return "MajorSchool [major_code=" + major_code + ", main_school=" + main_school + ", main_shool_id="
				+ main_shool_id + "]";
	}
	
}
