/**
 * 
 */
package com.cdut.entity;

/**
 * @author 大白菜
 *
 */
public class MajorCourse {
	private String  major_code;
	private String  course_id;
	private String  course_type;
	private String  course_kind;
	private String  exam_kind;
	private String  exam_type;
	private String belong;
	
	public MajorCourse(String major_code, String course_id, String course_type, String course_kind, String exam_kind,
			String exam_type, String belong) {
		super();
		this.major_code = major_code;
		this.course_id = course_id;
		this.course_type = course_type;
		this.course_kind = course_kind;
		this.exam_kind = exam_kind;
		this.exam_type = exam_type;
		this.belong = belong;
	}
	@Override
	public String toString() {
		return "MajorCourse [major_code=" + major_code + ", course_id=" + course_id + ", course_type=" + course_type
				+ ", course_kind=" + course_kind + ", exam_kind=" + exam_kind + ", exam_type=" + exam_type + ", belong="
				+ belong + "]";
	}
	public String getMajor_code() {
		return major_code;
	}
	public void setMajor_code(String major_code) {
		this.major_code = major_code;
	}
	public String getCourse_id() {
		return course_id;
	}
	public void setCourse_id(String course_id) {
		this.course_id = course_id;
	}
	public String getCourse_type() {
		return course_type;
	}
	public void setCourse_type(String course_type) {
		this.course_type = course_type;
	}
	public String getCourse_kind() {
		return course_kind;
	}
	public void setCourse_kind(String course_kind) {
		this.course_kind = course_kind;
	}
	public String getExam_kind() {
		return exam_kind;
	}
	public void setExam_kind(String exam_kind) {
		this.exam_kind = exam_kind;
	}
	public String getExam_type() {
		return exam_type;
	}
	public void setExam_type(String examtype) {
		this.exam_type = examtype;
	}
	public String getBelong() {
		return belong;
	}
	public void setBelong(String belong) {
		this.belong = belong;
	}
	
	
	

}
