
package com.cdut.entity;

/**
 * @author 大白菜
 *
 */
public class ExamPlan {
		private String exam_id;
		private String exam_plan_check_status;
		private String plan_check_suggest;
		private String xuelichu_suggest;
		private String leader_suggest;
		@Override
		public String toString() {
			return "ExamPlan [exam_id=" + exam_id + ", exam_plan_check_status=" + exam_plan_check_status
					+ ", plan_check_suggest=" + plan_check_suggest + ", xuelichu_suggest=" + xuelichu_suggest
					+ ", leader_suggest=" + leader_suggest + "]";
		}
		public String getExam_id() {
			return exam_id;
		}
		public void setExam_id(String exam_id) {
			this.exam_id = exam_id;
		}
		public String getExam_plan_check_status() {
			return exam_plan_check_status;
		}
		public void setExam_plan_check_status(String exam_plan_check_status) {
			this.exam_plan_check_status = exam_plan_check_status;
		}
		public String getPlan_check_suggest() {
			return plan_check_suggest;
		}
		public void setPlan_check_suggest(String plan_check_suggest) {
			this.plan_check_suggest = plan_check_suggest;
		}
		public String getXuelichu_suggest() {
			return xuelichu_suggest;
		}
		public void setXuelichu_suggest(String xuelichu_suggest) {
			this.xuelichu_suggest = xuelichu_suggest;
		}
		public String getLeader_suggest() {
			return leader_suggest;
		}
		public void setLeader_suggest(String leader_suggest) {
			this.leader_suggest = leader_suggest;
		}
		
}
