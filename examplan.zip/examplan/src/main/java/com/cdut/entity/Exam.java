
package com.cdut.entity;

import java.util.Date;

/**
 * @author 大白菜
 *
 */
public class Exam {
	private String exam_id;
	private String exam_type;
	private String plan_exam_status;
	private String start_date;
	private String end_date;
	@Override
	public String toString() {
		return "Exam [exam_id=" + exam_id + ", exam_type=" + exam_type + ", plan_exam_status=" + plan_exam_status
				+ ", start_date=" + start_date + ", end_date=" + end_date + "]";
	}
	public String getExam_id() {
		return exam_id;
	}
	public void setExam_id(String exam_id) {
		this.exam_id = exam_id;
	}
	public String getExam_type() {
		return exam_type;
	}
	public void setExam_type(String exam_type) {
		this.exam_type = exam_type;
	}
	public String getPlan_exam_status() {
		return plan_exam_status;
	}
	public void setPlan_exam_status(String plan_exam_status) {
		this.plan_exam_status = plan_exam_status;
	}
	public String getStart_date() {
		return start_date;
	}
	public void setStart_date(String start_date) {
		this.start_date = start_date;
	}
	public String getEnd_date() {
		return end_date;
	}
	public void setEnd_date(String end_date) {
		this.end_date = end_date;
	}
	
}
