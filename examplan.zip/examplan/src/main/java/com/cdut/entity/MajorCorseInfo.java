
package com.cdut.entity;

/**
 * @author 大白菜
 *
 */
public class MajorCorseInfo {
	private String major_code;//专业编码
	private String major_name;//专业名称
	private String  course_id;//课程编码
	private int  course_credit;//课程学分
	private String  course_name;//课程名称
	private String  course_type;//专业课、选考课、公共基础课
	private String  course_kind;//笔试、机考
	@Override
	public String toString() {
		return "MajorCorseInfo [major_code=" + major_code + ", major_name=" + major_name + ", course_id=" + course_id
				+ ", course_credit=" + course_credit + ", course_name=" + course_name + ", course_type=" + course_type
				+ ", course_kind=" + course_kind + "]";
	}
	public String getMajor_code() {
		return major_code;
	}
	public void setMajor_code(String major_code) {
		this.major_code = major_code;
	}
	public String getMajor_name() {
		return major_name;
	}
	public void setMajor_name(String major_name) {
		this.major_name = major_name;
	}
	public String getCourse_id() {
		return course_id;
	}
	public void setCourse_id(String course_id) {
		this.course_id = course_id;
	}
	public int getCourse_credit() {
		return course_credit;
	}
	public void setCourse_credit(int course_credit) {
		this.course_credit = course_credit;
	}
	public String getCourse_name() {
		return course_name;
	}
	public void setCourse_name(String course_name) {
		this.course_name = course_name;
	}
	public String getCourse_type() {
		return course_type;
	}
	public void setCourse_type(String course_type) {
		this.course_type = course_type;
	}
	public String getCourse_kind() {
		return course_kind;
	}
	public void setCourse_kind(String course_kind) {
		this.course_kind = course_kind;
	}
	
}
