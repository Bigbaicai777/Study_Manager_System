
package com.cdut.entity;

/**
 * @author 大白菜
 *
 */
public class Direction {
	private String major_code; //课程代码
	private int direction_id; //方向代码
	private String direction_name; //方向名称
	private int total_credit; //总学分
	@Override
	public String toString() {
		return "Direction [major_code=" + major_code + ", direction_id=" + direction_id + ", direction_name="
				+ direction_name + ", total_credit=" + total_credit + "]";
	}
	public String getMajor_code() {
		return major_code;
	}
	public void setMajor_code(String major_code) {
		this.major_code = major_code;
	}
	public int getDirection_id() {
		return direction_id;
	}
	public void setDirection_id(int direction_id) {
		this.direction_id = direction_id;
	}
	public String getDirection_name() {
		return direction_name;
	}
	public void setDirection_name(String direction_name) {
		this.direction_name = direction_name;
	}
	public int getTotal_credit() {
		return total_credit;
	}
	public void setTotal_credit(int total_credit) {
		this.total_credit = total_credit;
	}
	
	

}
