package com.cdut.entity;

public class Time {
private String exam_id;   
private String course_id;  //ʱ�����
private String date;
private String start_time; //��ʼʱ��
private String end_time;   //����ʱ��
private String exam_time;  
private String exam_type;   //��������
private String plan_exam_status;//�ƻ�����״̬
private String start_date;   //��ʼ����
private String end_date;     //��������
private Integer exam_free;   //ͳ����Ĭ���շ�
private String time_id;
public String getExam_id() {
	return exam_id;
}
public void setExam_id(String exam_id) {
	this.exam_id = exam_id;
}
public String getCourse_id() {
	return course_id;
}
public void setCourse_id(String course_id) {
	this.course_id = course_id;
}

public String getStart_time() {
	return start_time;
}
public void setStart_time(String start_time) {
	this.start_time = start_time;
}
public String getEnd_time() {
	return end_time;
}
public void setEnd_time(String end_time) {
	this.end_time = end_time;
}
public String getExam_time() {
	return exam_time;
}
public void setExam_time(String exam_time) {
	this.exam_time = exam_time;
}
public String getPlan_exam_status() {
	return plan_exam_status;
}
public void setPlan_exam_status(String plan_exam_status) {
	this.plan_exam_status = plan_exam_status;
}

public String getStart_date() {
	return start_date;
}
public void setStart_date(String start_date) {
	this.start_date = start_date;
}
public String getEnd_date() {
	return end_date;
}
public void setEnd_date(String end_date) {
	this.end_date = end_date;
}
public Integer getExam_free() {
	return exam_free;
}
public void setExam_free(Integer exam_free) {
	this.exam_free = exam_free;
}
public String getExam_type() {
	return exam_type;
}
public void setExam_type(String exam_type) {
	this.exam_type = exam_type;
}
public String getTime_id() {
	return time_id;
}
public void setTime_id(String time_id) {
	this.time_id = time_id;
}
public String getDate() {
	return date;
}
public void setDate(String date) {
	this.date = date;
}
}
