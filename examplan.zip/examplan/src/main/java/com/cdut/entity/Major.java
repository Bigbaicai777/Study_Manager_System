package com.cdut.entity;

/**
 *  Created By GoghV
 *  2020-09-17
 *  **/

public class Major {
	private String country_major; //����
	private String major_name; //����
	private String level; //���� ר�� �о���
	private int total_credit; //��ѧ��


	public String getCountry_major() {
		return country_major;
	}
	public void setCountry_major(String country_major) {
		this.country_major = country_major;
	}
	public String getMajor_name() {
		return major_name;
	}
	public void setMajor_name(String major_name) {
		this.major_name = major_name;
	}
	public String getLevel() {
		return level;
	}
	public void setLevel(String level) {
		this.level = level;
	}
	public int getTotal_credit() {
		return total_credit;
	}
	public void setTotal_credit(int total_credit) {
		this.total_credit = total_credit;
	}
	@Override
	public String toString() {
		return "Major [country_major=" + country_major + ", major_name=" + major_name + ", level=" + level
				+ ", total_credit=" + total_credit + "]";
	}
	
}
