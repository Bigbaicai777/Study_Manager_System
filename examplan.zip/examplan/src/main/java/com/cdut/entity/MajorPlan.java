package com.cdut.entity;

import java.sql.Date;



/**
 * @author GoghV
 */
public class MajorPlan {
	int id;
	String plan_version;
	String plan_name;
	String status;
	Date create_date;
	String approval_status;
	String xuelichu_suggest;
	String leader_idea;
	String major_code;
	String course_type;
	String course_kind;
	String course_id;
	String exam_kind;
	String exam_type;
	String belong;
	
	public String getCourse_id() {
		return course_id;
	}
	public void setCourse_id(String course_id) {
		this.course_id = course_id;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getPlan_version() {
		return plan_version;
	}
	public void setPlan_version(String plan_version) {
		this.plan_version = plan_version;
	}
	public String getPlan_name() {
		return plan_name;
	}
	public void setPlan_name(String plan_name) {
		this.plan_name = plan_name;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public Date getCreate_date() {
		return create_date;
	}
	public void setCreate_date(Date create_date) {
		this.create_date = create_date;
	}
	public String getApproval_status() {
		return approval_status;
	}
	public void setApproval_status(String approval_status) {
		this.approval_status = approval_status;
	}
	public String getXuelichu_suggest() {
		return xuelichu_suggest;
	}
	public void setXuelichu_suggest(String xuelichu_suggest) {
		this.xuelichu_suggest = xuelichu_suggest;
	}
	public String getLeader_idea() {
		return leader_idea;
	}
	public void setLeader_idea(String leader_idea) {
		this.leader_idea = leader_idea;
	}
	public String getMajor_code() {
		return major_code;
	}
	public void setMajor_code(String major_code) {
		this.major_code = major_code;
	}
	public String getCourse_type() {
		return course_type;
	}
	public void setCourse_type(String course_type) {
		this.course_type = course_type;
	}
	public String getCourse_kind() {
		return course_kind;
	}
	public void setCourse_kind(String course_kind) {
		this.course_kind = course_kind;
	}
	public String getExam_kind() {
		return exam_kind;
	}
	public void setExam_kind(String exam_kind) {
		this.exam_kind = exam_kind;
	}
	public String getExam_type() {
		return exam_type;
	}
	public void setExam_type(String exam_type) {
		this.exam_type = exam_type;
	}
	public String getBelong() {
		return belong;
	}
	public void setBelong(String belong) {
		this.belong = belong;
	}
	@Override
	public String toString() {
		return "MajorPlan [id=" + id + ", plan_version=" + plan_version + ", plan_name=" + plan_name + ", status="
				+ status + ", create_date=" + create_date + ", approval_status=" + approval_status
				+ ", xuelichu_suggest=" + xuelichu_suggest + ", leader_idea=" + leader_idea + ", major_code="
				+ major_code + ", course_type=" + course_type + ", course_kind=" + course_kind + ", course_id="
				+ course_id + ", exam_kind=" + exam_kind + ", exam_type=" + exam_type + ", belong=" + belong + "]";
	}
	
}
