package com.cdut.entity;

/**
 * @author Ayu
 * 2020-01-02
 */

public class Major_school {
	private String major_code;//רҵ����
	private String main_school;//����ԺУ
	private int main_school_id;//רҵ����ԺУ
	public String getMajor_code() {
		return major_code;
	}
	public void setMajor_code(String major_code) {
		this.major_code = major_code;
	}
	public String getMain_school() {
		return main_school;
	}
	public void setMain_school(String main_school) {
		this.main_school = main_school;
	}
	public int getMain_school_id() {
		return main_school_id;
	}
	public void setMain_school_id(int main_school_id) {
		this.main_school_id = main_school_id;
	}
	@Override
	public String toString() {
		return "Major_school [major_code=" + major_code + ", main_school=" + main_school + ", main_school_id="
				+ main_school_id + "]";
	}

}
