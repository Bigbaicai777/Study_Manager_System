package com.cdut.untils;


public class StringUntil {

   //判断目标字符串是否为空，true:表示为空，false：表示不为空
    public static boolean blank(String str){
        if(str==null || str.trim()=="" || str.trim().length()<=0){
            return true;
        }
        return false;
    }
}
