
package com.cdut.controller;

import java.util.List;

import com.cdut.Dao.ExamManagerDao;
import com.cdut.Dao.MajorDao;
import com.cdut.entity.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;



/**
 * @author 大白菜
 *
 */
@Controller
@RequestMapping("/emc")
public class ExManageController {
	 @Autowired
	 MajorDao majorDao;
	@Autowired
	ExamManagerDao examManagerDao;
	@RequestMapping("/examplan")
	public ModelAndView SelectExamPlan() {
		
		ModelAndView mv=new ModelAndView();
		List<Exam> list = examManagerDao.qurryAllExam();
		mv.addObject("lists", list);
		List<Major> list2 = majorDao.queryAll();
		mv.addObject("lists2", list2);
		mv.setViewName("examplan");
		return mv;
		
	}
	@RequestMapping("/submit")
	public ModelAndView SubExamPlan(@RequestParam("exam_id")String exam_id,@RequestParam("major_code")String major_code) {
		ModelAndView mv=new ModelAndView();
		System.out.println(exam_id+"---"+major_code);
		if(examManagerDao.addExamPlan(exam_id,major_code)!=0) {
			mv.addObject("status", "添加成功!");
			}
		//考次表
		List<Exam> list = examManagerDao.qurryAllExam();
		mv.addObject("lists", list);
		//专业表
		List<Major> list2 = majorDao.queryAll();
		mv.addObject("lists2", list2);
		mv.setViewName("examplan");
		return mv;
		
	}
	@RequestMapping("/setexam")//设置考次开考课表
	public ModelAndView ShowExamAndCourse() {
		ModelAndView mv=new ModelAndView();
		List<Course> list = examManagerDao.qurrtAllMajor();
		mv.addObject("lists", list);
		
		mv.setViewName("select_course_to_exam");
		return mv;
		
	}
	@RequestMapping("/toinput")//设置考次开考课表
	public ModelAndView input(@RequestParam("course_id")String course_id) {
		ModelAndView mv=new ModelAndView();
		List<ExamTime> list = examManagerDao.qurrtAllTime();
		mv.addObject("lists", list);
		mv.addObject("id", course_id);
		System.out.println("====="+course_id);
		mv.setViewName("input");
		return mv;
		
	}
	@RequestMapping("/insert")//设置考次开考课表
	public ModelAndView Insert(@RequestParam("exam_id")String exam_id,@RequestParam("course_id")String course_id,@RequestParam("time_id")String time_id) {
		ModelAndView mv=new ModelAndView();
		
		if(examManagerDao.insertById( exam_id, course_id,time_id)!=0) {
			mv.addObject("status", "添加成功!");
		}
		List<ExamTime> list = examManagerDao.qurrtAllTime();
		mv.addObject("lists", list);
		mv.addObject("id", course_id);
		mv.setViewName("input");
		return mv;
		
	}
	@RequestMapping("/check")//审核考试计划
	public ModelAndView check() {
		ModelAndView mv=new ModelAndView();
		List<ExamPlan> list = examManagerDao.qurrtAllExamPlan();
		mv.addObject("lists", list);
		mv.setViewName("check_exam");
		return mv;
		
	}
	
}
