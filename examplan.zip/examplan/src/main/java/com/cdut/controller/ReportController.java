package com.cdut.controller;

import java.util.List;

import com.cdut.Dao.Major_basicDao;
import com.cdut.Dao.ReportDao;
import com.cdut.entity.CountryCourse;
import com.cdut.entity.MajorSchool;
import com.cdut.entity.Major_basic;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;



@Controller
@RequestMapping("/report")
public class ReportController {
	
	@Autowired
	Major_basicDao major_basicDao;
	
	@Autowired
	ReportDao reportDao;
	
	@RequestMapping("/school_info")
	public ModelAndView schoolInfo() {
		ModelAndView mav = new ModelAndView();
		mav.setViewName("school_info");
		List<MajorSchool> list = reportDao.queryAllScholl();
		mav.addObject("list",list);
		return mav;
	}
	
	@RequestMapping("/major_basic")
	public ModelAndView majorBasic() {
		ModelAndView mav = new ModelAndView();
		mav.setViewName("major_all_info");
		List<Major_basic> list = major_basicDao.queryAll();
		mav.addObject("lists3",list);
		return mav;
	}
	
	@RequestMapping("/course_info")
	public ModelAndView courseInfo() {
		ModelAndView mav = new ModelAndView();
		mav.setViewName("course_info");
		List<CountryCourse> list = reportDao.queryAllCourse();
		mav.addObject("list",list);
		return mav;
	}
}
