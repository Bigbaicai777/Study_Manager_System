package com.cdut.controller;

import com.cdut.Dao.CourseDao;
import com.cdut.entity.Course;
import com.cdut.service.ICourseService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import java.util.List;


@Controller
@RequestMapping("/course")
public class CourseController {
    @Autowired
    ICourseService courseService;

    @RequestMapping("/all")
    public ModelAndView course() {
        ModelAndView mav = new ModelAndView();
        List<Course> list = courseService.queryAll();
        mav.addObject("lists", list);
        for (int i = 0; i < list.size(); i++) {
            Course course = list.get(i);
            System.out.println(course.getCourse_name());
        }
        mav.setViewName("courselist");
        return mav;
    }
    @RequestMapping("/course_bas_alter")
    public ModelAndView course_bas_alter(@RequestParam("country_course_id") String country_course_id){
        List<Course> list  = courseService.queryCourseById(country_course_id);
        ModelAndView model = new ModelAndView();
        model.addObject("lists", list);
        model.setViewName("course_bas_alter");
        return model;
    }

    @RequestMapping("/course_bas_alter_save")
    public String updateCourse(Course course){
        courseService.update(course);
        return "redirect:all";
    }

    @RequestMapping("/course_bas_insert")
    public String insertCourse(Course course){
        return "course_bas_insert";
    }

    @RequestMapping("/course_bas_insert_save")
    public String course_bas_insert_save(Course course){
        courseService.insertCourse(course);
        return "redirect:all";
    }

    @RequestMapping("/course_bas_delete")
    public String course_delete(@RequestParam("country_course_id") String country_course_id ){
        courseService.deleteById(country_course_id);
        return "redirect:all";
    }

    @RequestMapping("/country")
    public ModelAndView countrycourse() {
        ModelAndView mav = new ModelAndView();
        List<Course> list = courseService.queryCountryCourse();
        mav.addObject("lists", list);
        for (int i = 0; i < list.size(); i++) {
            Course course = list.get(i);
            System.out.println(course.getCourse_name());
        }
        mav.setViewName("country_course");
        return mav;
    }


    @RequestMapping("/set")
    public ModelAndView setCourse(@RequestParam("course_id") String course_id) {
        ModelAndView mv = new ModelAndView();
        List<Course> list = courseService.queryAll();
        mv.addObject("course_code", course_id);
        mv.addObject("list", list);
        mv.setViewName("exam_course");
        return mv;
    }

    //�γ�ͣ�á�����
    @RequestMapping("/course_normal")
    public ModelAndView majornomal() {
        ModelAndView mav = new ModelAndView();
        List<Course> list = courseService.queryNor("停用");
        mav.addObject("lists5", list);
        mav.setViewName("course_normal");
        return mav;
    }

    @RequestMapping("/course_nor_alter")
    public ModelAndView major_nor_alter(@RequestParam("course_id") String code) {
        ModelAndView mav = new ModelAndView();
        courseService.startByCode(code);
        mav.setViewName("redirect:course_stop");
        return mav;
    }


    //1����רҵͣ��
    @RequestMapping("/course_stop")
    public ModelAndView majorstop() {
        ModelAndView mav = new ModelAndView();
        List<Course> list = courseService.queryNor("正常");
        mav.addObject("lists5", list);
        mav.setViewName("course_stop");
        return mav;
    }

    @RequestMapping("/course_stop_alter")
    public ModelAndView course_stop_alter(@RequestParam("course_id") String code) {
        ModelAndView mav = new ModelAndView();
        courseService.stopByCode(code);
        mav.setViewName("redirect:course_normal");
        return mav;
    }



}
