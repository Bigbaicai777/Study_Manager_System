package com.cdut.controller;


import com.cdut.entity.User;
import com.cdut.service.IUserService;
import com.cdut.untils.StringUntil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpSession;
import java.sql.SQLException;
import java.util.Map;


@Controller
@RequestMapping("/user")
public class UserController {
    @Autowired
    private IUserService userService;


    @RequestMapping("/login")
    public ModelAndView login(User user, Map<String,Object> map) throws SQLException {
        System.out.println(user.getUsername()+user.getPwd());
        ModelAndView mv = new ModelAndView();
        mv.setViewName("login");
        String pwd;
        User u = new User();
        try {
            //查询数据库
            u= userService.getByUsername(user.getUsername());
            pwd = u.getPwd();
        }catch (Exception e){
            mv.addObject("msg","用户不存在！");
            return mv;
        }

        if(user.getPwd().equals(pwd)) {
            mv.setViewName("index");
        }
        else {
            mv.addObject("msg","登陆失败！密码或账号错误！");
        }
        return mv;

    }

}
