package com.cdut.controller;

import java.util.List;

import com.cdut.Dao.MajorDao;
import com.cdut.Dao.MajorManagerDao;
import com.cdut.entity.*;
import com.cdut.mapper.IMajorManagerMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;



@Controller
@RequestMapping("/mcc")
public class MajorCourseController {

	@Autowired
    IMajorManagerMapper majorManagerMapper;
	@Autowired
	JdbcTemplate jdbcTemplate;
	 @Autowired
	 MajorManagerDao majorManagerDao;
	 @Autowired
	 MajorDao majorDao;
	@RequestMapping("/select")
	public ModelAndView majorInfo() {
		ModelAndView mav = new ModelAndView();
		List<Major> list = majorDao.queryAll();
		mav.addObject("lists", list);
		mav.setViewName("major_select");
		return mav;
	}
	@RequestMapping("/set")
	public ModelAndView setMajorCourse(@RequestParam("country_major") String country_major) {
		ModelAndView mv=new ModelAndView();
		List<ShowMajorCourse> list=majorManagerDao.showMajorCourse(country_major);
		mv.addObject("major_code", country_major);
		mv.addObject("list", list);
		mv.setViewName("showmajorcourse");
		return mv;
	}
	@RequestMapping("/submit")
	public ModelAndView Submit(@RequestParam("major_code") String major_code,
			@RequestParam("course_id") String course_id,
			@RequestParam("course_type") String course_type,
			@RequestParam("course_kind") String course_kind,
			@RequestParam("exam_kind") String exam_kind,
			@RequestParam("exam_type") String exam_type,
			@RequestParam("belong") String belong
	) {
		MajorCourse mc=new MajorCourse(major_code, course_id, course_type, course_kind, exam_kind, exam_type, belong);
		ModelAndView mv=new ModelAndView();
		majorManagerDao.setMajorCourse(mc);
		List<MajorCorseInfo> ls=majorManagerDao.QurreyMCInfo(major_code, course_id);
		mv.addObject("ls", ls);
		mv.addObject("major_code", major_code);
		mv.setViewName("showmajor");
		return mv;
	}
	@RequestMapping("/dir")
	public ModelAndView Direction() {
		ModelAndView mv=new ModelAndView();
		List<Major_basic> list = majorManagerDao.qurreyAllMajor();
		mv.addObject("lists", list);
		mv.setViewName("setdir");
		return mv;
		
	}
	@RequestMapping("/gra")
	public ModelAndView Graduate() {
		ModelAndView mv=new ModelAndView();
		List<Major_basic> list = majorManagerDao.qurreyAllMajor();
		mv.addObject("lists", list);
		mv.setViewName("setgra");
		return mv;
		
	}
	@RequestMapping("/setdir")
	public ModelAndView SetDirection(@RequestParam("major_code")String major_code) {
		ModelAndView mv=new ModelAndView();
		List<Direction> list = majorManagerDao.ManageDir(major_code);
		mv.addObject("lists", list);
		mv.setViewName("managdir");
		return mv;
		
	}
	@RequestMapping("/change")
	public ModelAndView toChange(@RequestParam("major_code")String major_code) {
		ModelAndView mv=new ModelAndView();
		List<Major_basic> list = majorManagerMapper.qurreyByCode(major_code);
		//System.out.println("list="+list.toString());
		mv.addObject("list", list);
		mv.setViewName("change_gra");
		return mv;
	}
	@RequestMapping("/updategra")
	public ModelAndView updateGra(Major_basic major_basic) {
		ModelAndView mv=new ModelAndView();
		System.out.println(major_basic.toString());
		majorManagerDao.updateGra(major_basic.getMajor_code(),major_basic.getGraduate_explain());
		List<Major_basic> list = majorManagerDao.qurreyAllMajor();
		mv.addObject("lists", list);
		mv.setViewName("setgra");
		return mv;
		
	}
}
