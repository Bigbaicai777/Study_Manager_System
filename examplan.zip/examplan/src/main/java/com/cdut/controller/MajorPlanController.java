package com.cdut.controller;

import java.sql.Date;
import java.util.List;

import com.cdut.Dao.MajorPlanDao;
import com.cdut.entity.MajorPlan;
import com.cdut.service.IMajorPlanService;
import com.cdut.service.Impl.MajorPlanServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

/**
 * @author GoghV
 */

@Controller
@RequestMapping("/plan")
public class MajorPlanController {

	@Autowired
	IMajorPlanService majorPlanService;
	
	@RequestMapping("/plan_publish_table")
	public ModelAndView planPublishTable() {
		ModelAndView mav = new ModelAndView();
		mav.setViewName("plan_publish_table");
		List<MajorPlan> list = majorPlanService.queryCanPublish();
		mav.addObject("list",list);
		return mav;
	}
	
	@RequestMapping("/publish")
	public ModelAndView publish(int id) {
		majorPlanService.publish(id);
		ModelAndView mav = new ModelAndView();
		mav.setViewName("plan_table");
		List<MajorPlan> list = majorPlanService.queryAll();
		mav.addObject("list",list);
		return mav;
	}
	
	@RequestMapping("/confirm")
	public ModelAndView confirm(int id,int status) {
		if(status==1) {
			majorPlanService.pass(id);
		}else {
			majorPlanService.refuse(id);
		}
		ModelAndView mav = new ModelAndView();
		mav.setViewName("plan_table");
		List<MajorPlan> list = majorPlanService.queryAll();
		mav.addObject("list",list);
		return mav;
	}
	@RequestMapping("/plan_confirm_table")
	public ModelAndView planConfirmTable() {
		ModelAndView mav = new ModelAndView();
		List<MajorPlan> list = majorPlanService.queryPlanTable();
		mav.addObject("list",list);
		mav.setViewName("plan_confirm_table");
		return mav;
	}
	
	@RequestMapping("/plan_table")
	public ModelAndView planTable() {
		ModelAndView mav = new ModelAndView();
		mav.setViewName("plan_table");
		List<MajorPlan> list = majorPlanService.queryAll();
		mav.addObject("list",list);
		return mav;
	}
	
	@RequestMapping("/edit")
	public ModelAndView planEdit(@RequestParam("id") int id,@RequestParam("major_code") String major_code) {
		ModelAndView mav = new ModelAndView();
		mav.setViewName("plan_edit");
		List<MajorPlan> list = majorPlanService.queryMajorCourse(major_code);
		for(int i=0;i<list.size();i++) {
			System.out.println("创建计划："+list.get(i).toString());
		}
		mav.addObject("list",list);
		return mav;
	}
	
	@RequestMapping("/edit_confirm")
	public ModelAndView editConfirm(MajorPlan majorPlan){

		majorPlan.setPlan_version(String.valueOf(Integer.valueOf(majorPlan.getPlan_version()) + 1));
		System.out.println(majorPlan.toString());
		majorPlanService.insert(majorPlan);
		ModelAndView mav = new ModelAndView();
		mav.setViewName("plan_table");
		List<MajorPlan> list = majorPlanService.queryAll();
		mav.addObject("list",list);
		return mav;
	}
	
	@RequestMapping("/plan_update_table")
	public ModelAndView planUpdate() {
		ModelAndView mav = new ModelAndView();
		mav.setViewName("plan_update_table");
		List<MajorPlan> list = majorPlanService.queryAll();
		mav.addObject("list",list);
		return mav;
	}
	
	@RequestMapping("/update")
	public ModelAndView planUpdate(@RequestParam("id") int id,@RequestParam("major_code") String major_code) {
		ModelAndView mav = new ModelAndView();
		mav.setViewName("plan_update");
		List<MajorPlan> list = majorPlanService.queryMajorCourse(major_code);
		mav.addObject("list",list);
		return mav;
	}
	
	@RequestMapping("/update_confirm")
	public ModelAndView updateConfirm(MajorPlan majorPlan) {
		int tempPlanVersion = Integer.valueOf(majorPlan.getPlan_version());
		majorPlan.setPlan_version(String.valueOf(tempPlanVersion));
		majorPlanService.update(majorPlan);
		ModelAndView mav = new ModelAndView();
		mav.setViewName("plan_update_table");
		List<MajorPlan> list = majorPlanService.queryAll();
		mav.addObject("list",list);
		return mav;
	}
}
