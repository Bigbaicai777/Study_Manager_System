package com.cdut.controller;

import java.util.List;

import com.cdut.Dao.TimeDao;
import com.cdut.entity.Time;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;


@Controller
@RequestMapping("/time")
public class TimeController {
	@Autowired
	JdbcTemplate jdbcTemplate;
	 @Autowired
	 TimeDao timeDao;
	 //����
	@RequestMapping("/exam")
	public ModelAndView time() {
		ModelAndView mav = new ModelAndView();
		List<Time> list = timeDao.queryAll();
		mav.addObject("lists", list);
		for(int i=0;i<list.size();i++) {
			Time time = list.get(i);
		}
		mav.setViewName("exam_time");
		return mav;
	}
	//����ʱ��
	@RequestMapping("/examtime")
	public ModelAndView examcourse() {
		ModelAndView mav = new ModelAndView();
		List<Time> list = timeDao.queryExamCourse();
		mav.addObject("lists", list);
		for(int i=0;i<list.size();i++) {
			Time time = list.get(i);
		}
		mav.setViewName("exam_course");
		return mav;
	}
	//��������
	@RequestMapping("/submit")
	public ModelAndView Submit(@RequestParam("exam_id") String exam_id) {
		ModelAndView mv=new ModelAndView();
		List<Time> list=timeDao.showTime();
		mv.addObject("list", list);
		mv.setViewName("exam_time");
		return mv;
	}
	@RequestMapping("/add")
	public String index() {
		return "set_exam_time";
	}
	//��������ʱ��
	/*
	 * @RequestMapping("/add") public ModelAndView Add(@RequestParam("exam_id")
	 * String exam_id) { ModelAndView mv=new ModelAndView(); List<Time>
	 * list=timeDao.showExamTime(); mv.addObject("list", list);
	 * mv.setViewName("exam_course"); return mv; }
	 */

}
