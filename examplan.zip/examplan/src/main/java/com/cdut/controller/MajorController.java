package com.cdut.controller;

import java.io.IOException;
import java.util.List;

import com.cdut.Dao.MajorDao;
import com.cdut.Dao.Major_basicDao;
import com.cdut.Dao.Major_schoolDao;
import com.cdut.entity.Major;
import com.cdut.entity.Major_basic;
import com.cdut.entity.Major_school;
import com.cdut.service.IMajorService;
import com.cdut.service.Impl.MajorPlanServiceImpl;
import net.sf.json.JSONObject;

import org.json.JSONArray;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


/**
 * @author Goghv&Ayu
 * 2020-9-14
 */
@Controller
@RequestMapping("/goghv")
public class MajorController {

    @Autowired
    IMajorService majorService;
    @RequestMapping("/major_info")
    public ModelAndView majorInfo() {
        ModelAndView mav = new ModelAndView();
        List<Major> list = majorService.queryAllCountry_major();
        mav.addObject("lists", list);
        for (int i = 0; i < list.size(); i++) {
            Major major = list.get(i);
            System.out.println(major.getMajor_name());
        }
        mav.setViewName("major_info");
        return mav;
    }
    @RequestMapping("/a3")
    public void a3(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String data = req.getParameter("data");
        JSONObject json =  JSONObject.fromObject(data);
        Major major = new Major();
        major.setCountry_major(json.getString("country_major"));
        major.setLevel(json.getString("level"));
        major.setMajor_name(json.getString("major_name"));
        major.setTotal_credit(json.getInt("total_credit"));
        majorService.updateCountryMajor(major);
        System.out.println(major.toString());
    }

    @RequestMapping("/deleterow")
    public void deleterow(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String data = req.getParameter("data");
        JSONObject json =  JSONObject.fromObject(data);
        String country_major=json.getString("country_major");
        majorService.deleteCountryMajor(country_major);
        System.out.println(country_major);
    }

    @RequestMapping("/index")
    public String index() {
        return "index";
    }

    @RequestMapping("/major_school")
    public ModelAndView majorscho() {
        ModelAndView mav = new ModelAndView();
        List<Major_school> list = majorService.queryAllMajor_school();
        mav.addObject("lists2", list);
        for (int i = 0; i < list.size(); i++) {
            Major_school major_sch = list.get(i);
            System.out.println(major_sch.getMajor_code());
        }
        mav.setViewName("major_school");
        return mav;
    }

    @RequestMapping("/major_basic")
    public ModelAndView majorbasic() {
        ModelAndView mav = new ModelAndView();
        List<Major_basic> list = majorService.queryAllMajor();
        mav.addObject("lists3", list);
        mav.setViewName("major_basic");
        return mav;
    }

    @RequestMapping("/major_bas_alter")
    public ModelAndView major_bas_alter(@RequestParam("country_major_code") String code) {
        ModelAndView mav = new ModelAndView();
        List<Major_basic> list = majorService.findMajorinfoByCode(code);
        for (int i = 0; i < list.size(); i++) {
            System.out.println(list.get(i).toString());
        }
        mav.addObject("lists4", list);
        mav.setViewName("major_bas_alter");
        return mav;
    }

    @RequestMapping("/major_bas_alter_save")
    public ModelAndView major_bas_alter_save(Major_basic alter) {

        ModelAndView mav = new ModelAndView();
        majorService.updateMajor(alter);
        List<Major_basic> list = majorService.queryAllMajor();
        mav.addObject("lists3", list);
        mav.setViewName("major_basic");
        return mav;
    }

    @RequestMapping("/major_bas_insert")
    public String major_bas_alter() {
        return "major_bas_insert";
    }

    @RequestMapping("/major_bas_alter_insert")
    public ModelAndView major_bas_alter_insert(Major_basic alter) {
        System.out.println(alter.toString());
        ModelAndView mav = new ModelAndView();
        majorService.insertMajor(alter);
        List<Major_basic> list = majorService.queryAllMajor();
        mav.addObject("lists3", list);
        mav.setViewName("major_basic");
        return mav;
    }

    @RequestMapping("/major_bas_delete")
    public ModelAndView major_bas_delete(@RequestParam("country_major_code") String code) {
        System.out.println(code.toString());
        ModelAndView mav = new ModelAndView();
        majorService.deleteMajor(code);
        List<Major_basic> list = majorService.queryAllMajor();
        mav.addObject("lists3", list);
        mav.setViewName("major_basic");
        return mav;
    }

    @RequestMapping("/major_normal")
    public ModelAndView majornomal() {
        ModelAndView mav = new ModelAndView();
        List<Major_basic> list = majorService.queryNor(0);
        mav.addObject("lists5", list);
        mav.setViewName("major_normal");
        System.out.println("跳了");
        return mav;
    }

    @RequestMapping("/major_nor_alter")
    public ModelAndView major_nor_alter(@RequestParam("country_major_code") String code) {
        ModelAndView mav = new ModelAndView();
        majorService.startByCode(code);
        mav.setViewName("redirect:major_stop");
        return mav;
    }

    @RequestMapping("/major_stop")
    public ModelAndView majorstop() {
        ModelAndView mav = new ModelAndView();
        List<Major_basic> list = majorService.queryNor(1);
        mav.addObject("lists5", list);
        mav.setViewName("major_stop");
        return mav;
    }
    @RequestMapping("/major_stop_alter")
    public String major_stop_alter(@RequestParam("country_major_code") String code) {
        ModelAndView mav = new ModelAndView();
        majorService.stopByCode(code);
        return "redirect:major_normal";//跳到另一个controller里
    }


}
